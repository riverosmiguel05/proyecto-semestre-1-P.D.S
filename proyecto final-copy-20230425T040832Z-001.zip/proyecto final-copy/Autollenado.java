public class Autollenado {
  private int _tankPin;
  private int _valvePin;
  private boolean _isEmpty;
  
  public Autollenado(int tankPin, int valvePin) {
    _tankPin = tankPin;
    _valvePin = valvePin;
    _isEmpty = true;
    // Initialization code goes here
  }
    
  public void fillTank() {
    if (_isEmpty) {
      // Open the valve to fill the tank
      digitalWrite(_valvePin, HIGH);
        
      // Wait for the tank to fill up
      if (analogRead(_tankPin) >= 100) {
        // Close the valve to stop filling the tank
        digitalWrite(_valvePin, LOW);
          
        // Update the status of the tank
        _isEmpty = false;
      }
    }
  }
    
  public void run(int fillTank) {
    // Code for normal operations goes here
    // ...
    // If necessary, fill the tank
    fillTank(0);
  }
}


