import javax.swing.*;
import java.awt.*;

public class LoginGU extends JFrame {
  private JPanel panel;
  private JTextField txtUsuario;
  private JPasswordField txtPassword;
  private JButton btnIngresar;

  public LoginGU() {
    this.setTitle("Inicio de sesión");
    this.setSize(300, 200);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    panel = new JPanel();
    panel.setLayout(new GridLayout(3, 2));
    panel.add(new JLabel("Usuario:"));
    txtUsuario = new JTextField();
    panel.add(txtUsuario);
    panel.add(new JLabel("Contraseña:"));
    txtPassword = new JPasswordField();
    panel.add(txtPassword);
    btnIngresar = new JButton("Ingresar");
    panel.add(btnIngresar);
    this.add(panel);

    this.setVisible(true);
  }

  public static void main(String[] args) {
    LoginGU gui = new LoginGU();
  }
}
