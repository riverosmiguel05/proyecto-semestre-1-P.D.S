
import javax.swing.*;
import java.awt.*;
import java.lang.String;

public class LoginGUI extends JFrame {
  private JPanel panel;
  private JTextField txtUsuario;
  private JPasswordField txtPassword;
  private JButton btnIngresar;
  private ConexionBD conexion; // declare instance of ConexionBD
  
  public LoginGUI() {
    this.setTitle("Inicio de sesión");
    this.setSize(300, 200);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    conexion = new ConexionBD(); // initialize instance of ConexionBD
    
    panel = new JPanel();
    panel.setLayout(new GridLayout(3, 2));
    panel.add(new JLabel("Usuario:"));
    txtUsuario = new JTextField();
    panel.add(txtUsuario);
    panel.add(new JLabel("Contraseña:"));
    txtPassword = new JPasswordField();
    panel.add(txtPassword);
    btnIngresar = new JButton("Ingresar");
    btnIngresar.addActionListener(e -> verificarCredenciales());
    panel.add(btnIngresar);

    this.add(panel);

    this.setVisible(true);
  }
  
  private void verificarCredenciales() {
    // Get the username and password from the text boxes
    String usuario = txtUsuario.getText();
    String contrasena = new String(txtPassword.getPassword());
    
    // Use the ConexionBD instance to query the database
    boolean autenticado = conexion.verificarCredenciales(usuario, contrasena); // add dot before method name
    
    if (autenticado) {
      JOptionPane.showMessageDialog(null, "Inicio de sesion exitoso");
    } else {
      JOptionPane.showMessageDialog(null, "Credenciales incorrectas");
    }
  }

  public static void main(String[] args) {
    LoginGUI gui = new LoginGUI();
  }
}

