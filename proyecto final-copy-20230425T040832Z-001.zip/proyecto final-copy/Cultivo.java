
import java.util.Scanner;
import java.lang.String;

public class Cultivo {
    private String descripcionPlanta;
    private ConexionBD conexion;

    public Cultivo() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese la descripción de la planta: ");
        descripcionPlanta = scanner.nextLine();
        conexion = new ConexionBD();
        conexion.insertarDescripcion(descripcionPlanta);
        conexion.desconectar();
    }

    public String getDescripcionPlanta() {
        return descripcionPlanta;
    }
}

