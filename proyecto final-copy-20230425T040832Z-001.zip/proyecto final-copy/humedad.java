
import java.util.Scanner;
import java.sql.*;

public class humedad {
    private ConexionBD conexion;
    private double humedadIdeal;
    private double humedadActual;

    public humedad(double temperaturaIdeal) {
        this.humedadIdeal = humedadIdeal;
        conexion = new ConexionBD();
    }

    public void actualizarhumedad(double nuevahumedad) {
        humedadActual = nuevahumedad;
        // Insertar la temperatura actual en la base de datos
        try {
            String sql = "INSERT INTO Temperatura (temperaturaIdeal, temperaturaActual) VALUES (?, ?)";
            PreparedStatement pstmt = conexion.getConexion().prepareStatement(sql);
            pstmt.setDouble(1, humedadIdeal);
            pstmt.setDouble(2, humedadActual);
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public double gethumedadraIdeal() {
        return humedadIdeal;
    }

    public double gethumedadActual() {
        // Simular la lectura de temperatura desde el arduino
        humedadActual = Math.random() * 10 + humedadIdeal;
        return humedadActual;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese la humedad ideal: ");
        double humedadIdeal = scanner.nextDouble();
        humedad humedad = new humedad(humedadIdeal);
        double nuevaHumedad = humedad.gethumedadActual();
        System.out.println("La humedad actual es: " + nuevaHumedad);
        humedad.actualizarhumedad(nuevaHumedad);
    }
}
