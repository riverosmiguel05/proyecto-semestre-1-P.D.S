
import java.util.Scanner;
import java.sql.*;

public class Temperatura {
    private ConexionBD conexion;
    private double temperaturaIdeal;
    private double temperaturaActual;

    public Temperatura(double temperaturaIdeal) {
        this.temperaturaIdeal = temperaturaIdeal;
        conexion = new ConexionBD();
    }

    public void actualizarTemperatura(double nuevaTemperatura) {
        temperaturaActual = nuevaTemperatura;
        // Insertar la temperatura actual en la base de datos
        try {
            String sql = "INSERT INTO Temperatura (temperaturaIdeal, temperaturaActual) VALUES (?, ?)";
            PreparedStatement pstmt = conexion.getConexion().prepareStatement(sql);
            pstmt.setDouble(1, temperaturaIdeal);
            pstmt.setDouble(2, temperaturaActual);
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public double getTemperaturaIdeal() {
        return temperaturaIdeal;
    }

    public double getTemperaturaActual() {
        // Simular la lectura de temperatura desde el arduino
        temperaturaActual = Math.random() * 10 + temperaturaIdeal;
        return temperaturaActual;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese la temperatura ideal: ");
        double temperaturaIdeal = scanner.nextDouble();
        Temperatura temperatura = new Temperatura(temperaturaIdeal);
        double nuevaTemperatura = temperatura.getTemperaturaActual();
        System.out.println("La temperatura actual es: " + nuevaTemperatura);
        temperatura.actualizarTemperatura(nuevaTemperatura);
    }
}
