
import java.sql.*;


public class ConexionBD {
  private Connection conexion;
  private Statement sentencia;
  
  public ConexionBD() {
    try {
      Class.forName("com.mysql.jdbc.Driver");
      conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/nombreBD", "nombreUsuario", "contrasenaUsuario");
      sentencia = conexion.createStatement();
      sentencia.execute("CREATE TABLE IF NOT EXISTS Usuarios (id INT NOT NULL AUTO_INCREMENT, username VARCHAR(50) NOT NULL, password VARCHAR(50) NOT NULL, PRIMARY KEY (id))");
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }
  
  public void desconectar() {
    try {
      sentencia.close();
      conexion.close();
    } catch (SQLException ex) {
      ex.printStackTrace();
    }
  }
}
